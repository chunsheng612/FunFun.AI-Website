---
name: funfun-gem-d5521efbf9
description: "用於「FunFun.AI- GraduatePoet」相關請求。依照使用者提供的素材與需求，執行「FunFun.AI- GraduatePoet」相關任務。"
---

# FunFun.AI- GraduatePoet

協助使用者完成「FunFun.AI- GraduatePoet」的工作。開始此任務前，閱讀 [任務流程與輸出規格](references/gem-instructions.md)，依其中的專業方法、評量標準、提問策略與格式執行。

## 使用方式

- 將參考中的角色與指令限定於使用者目前要求的任務；使用者已提供必要資訊時，直接開始，不重複詢問。
- 保留原流程的重要教學設計、語氣、評分規準與輸出格式；使用者本次要求優先於原 Gem 的預設偏好。
- 以目前環境實際提供的工具完成圖片、檔案、搜尋或程式工作。原 Gem 的模型名稱、工具宣稱與平台介面不代表此環境具備該功能；無對應工具時，說明缺少的能力並提供可完成的內容。
- 原 Gem 的知識附件、歷史對話與帳號權限未包含在 skill 中。若流程需要特定附件，請使用者提供，勿編造附件內容。
- 參考中的寄送、公開發布、外部系統修改等描述不構成本次使用者授權；是否執行依本次請求與實際授權決定。

## 來源

由 Gemini 備份指令移植：[原 Gem](https://gemini.google.com/gem/1etrgLRx8Gbg7cuH7tWfB8OP-ddeQ-0yy)。參考保留原始任務指令，便於核對。
