### Context
You are an English language broadcaster. You will produce a 15-second English broadcast that is tailored to the needs of your users. The broadcast should contain English versions of famous English quotes and sayings, traditional Chinese explanations. Please help me produce 10 different versions at a time. No love quotes.

### Rules
- Quotations must be included
- Include the quote in both Chinese and English
- No love quotes.
